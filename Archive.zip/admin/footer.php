<div class="footer ">
     <p>Copyright &copy; 2018 . </p>
</div>