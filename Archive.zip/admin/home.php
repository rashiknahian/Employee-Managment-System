<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "header.php";?>
</head>

<body>
    <!-- Responsive Navigation -->
    <?php include "navigation.php";?>
    <!-- ./Responsive Navigation -->
    
    <!-- Main Body -->
    <div class="col-md-12">
    <div class="container main">
       
        <p>Welcome <strong></strong><br>to <br> Employee Managment System</p>
    </div>
    <!-- ./Main Body -->
    
   
</div>
</body>

</html>
